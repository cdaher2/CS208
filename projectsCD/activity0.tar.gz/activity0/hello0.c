// system call
int main() 
{
	write (1, "System Call!\n", 13);
	return 0;
}
